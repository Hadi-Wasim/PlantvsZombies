#ifndef SUN_H
#define SUN_H

#include "SFML/Graphics.hpp"
#include <iostream>
#include <cstdlib>  // Include the header for rand()
#include <ctime>    // Include the header for srand() to seed the random number generator


using namespace sf;
using namespace std;

class Sun {
private:
    RenderWindow& window;
    Sprite sunSprite;
    Texture sunTexture;
    bool isActive;
    static int sunPoints;
    Font font;
    Text scoreText;
    Clock activeTimer;  // Only for managing how long the sun stays active
    bool isStatic;  // Indicates if the sun should remain static or move

    void updateScoreText() {
        scoreText.setString(to_string(sunPoints));
        cout << "sunpoints" << sunPoints;
    }

public:
    Sun(RenderWindow& win,bool stat) : window(win), isActive(false), isStatic(stat) 
    {
        sunTexture.loadFromFile("Images/Sun_0.png");
        sunSprite.setTexture(sunTexture);
        srand(static_cast<unsigned int>(time(nullptr)));

        if (!font.loadFromFile("Images/assets/fonts/serio.ttf")) {
            // Handle font loading error
            throw std::runtime_error("Failed to load font.");
        }
        scoreText.setFont(font);
        scoreText.setCharacterSize(30);
        scoreText.setFillColor(Color::Black);
        scoreText.setPosition(25, 135); // Position at bottom left corner
        
    }

    // Method to spawn the sun at specific coordinates
    void spawn(bool staticSun) 
    {
        if (!isActive && !staticSun) 
        {

            // Generate a random number between 240 and 1100
            int randomNumber = rand() % (1100 - 240 + 1) + 240;
            float x = staticSun ? 400 : rand() % 800;  // Randomize x position if not static
            float y = -50;
            sunSprite.setPosition(x, y);
            isActive = true;
            isStatic = staticSun;
            activeTimer.restart();
        }
        
    }
    void spawnStatic(int x, int y)
    {
        sunSprite.setPosition(x, y);
        isActive = true;
        isStatic = true;
        
    }
    void update() 
    {
        if (isActive) 
        {
            if (isStatic) 
            {
                if (activeTimer.getElapsedTime().asSeconds() >= 10.0) 
                {
                    isActive = false;  // Deactivate the sun after 6 seconds
                }
                else
                    sunSprite.setPosition(sunSprite.getPosition().x, sunSprite.getPosition().y);  // Set new position

            }
            else 
            {
                // Update sun's position for moving sun
                
                if (!(sunSprite.getPosition().y >= 600))
                {
                    float speed = 0.1f;  // Adjust speed as needed
                    float newY = sunSprite.getPosition().y + speed;  // Calculate new y position
                    sunSprite.setPosition(sunSprite.getPosition().x, newY);  // Set new position
                }
                else
                    isStatic = 1;
            }
        }
    }

    void draw(RenderWindow& window) 
    {
        if (isActive)
        {
            window.draw(sunSprite);
            
        }
        window.draw(scoreText);

    }

    bool isClicked(RenderWindow& window) 
    {
        float X = Mouse::getPosition(window).x;

        float Y = Mouse::getPosition(window).y;
        if (isActive && sunSprite.getGlobalBounds().contains(X,Y))
        {
            if(Mouse::isButtonPressed(Mouse::Left))
            {
                isActive = false;  // Sun is collected
                sunPoints += 25;
                updateScoreText();
                return true;
            }
        }
        return false;
    }
    static int getSunPoints() { return sunPoints; }
    static void setSunPoints(int x) { sunPoints = x; }
};
int Sun::sunPoints = 500;
#endif