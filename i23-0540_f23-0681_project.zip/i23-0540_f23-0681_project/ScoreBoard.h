#ifndef SCORE_H
#define SCORE_H

#include "SFML/Graphics.hpp"
#include <string>

using namespace sf;
using namespace std;

class ScoreBoard {
private:
    Font font;
    Text scoreText;
    unsigned int score;
    void updateScoreText() {
        scoreText.setString("Score: " + to_string(score));
    }
public:
    ScoreBoard() : score(0) {
        if (!font.loadFromFile("Images/assets/fonts/Samdan.ttf")) {
            // Handle font loading error
            throw std::runtime_error("Failed to load font.");
        }

        scoreText.setFont(font);
        scoreText.setCharacterSize(50);
        scoreText.setFillColor(Color::White);
        scoreText.setPosition(100, 800); // Position at bottom left corner
        updateScoreText();
    }

    void updateScore(unsigned int newScore) {
        score = newScore;
        updateScoreText();
    }

    void draw(RenderWindow& window) {
        updateScoreText();
        window.draw(scoreText);
    }


};
#endif // !SCORE_H
