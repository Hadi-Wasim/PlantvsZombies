#ifndef SCREENMANAGER_H
#define SCREENMANAGER_H
#include "InstructionMenu.h"
#include "MainMenu.h"
#include "HighScore.h"
#include "PlayLevels.h"


class ScreenManager {
    RenderWindow& window;
    MainMenu* mainMenu;
    InstructionsScreen* instructions;
    PlayGame* playScreen;
    Screens* currentScreen;
    HighScoreScreen* highScoreScreen;

public:
    ScreenManager(RenderWindow& window) : window(window) {
        instructions = new InstructionsScreen(window);
        mainMenu = new MainMenu(window);
        highScoreScreen = new HighScoreScreen(window);
        playScreen = new PlayGame(window);
        currentScreen = mainMenu;
    }
    void handleEvents() {
        currentScreen->handleEvents(window);
    }
    // Getter for currentScreen
    Screens* getCurrentScreen() {
        return currentScreen;
    }

    // Setter for currentScreen
    void setCurrentScreen(Screens* screen) {
        if (currentScreen)
            delete currentScreen;
        currentScreen = screen;
    }

    // Getter for mainMenu
    MainMenu* getMainMenu() const {
        return mainMenu;
    }

    // Setter for mainMenu
    void setMainMenu(MainMenu* menu) {
        mainMenu = menu;
    }

    // Getter for instructions
    InstructionsScreen* getInstructions() const {
        return instructions;
    }

    // Setter for instructions
    void setInstructions(InstructionsScreen* instructions) {
        this->instructions = instructions;
    }
    void moveToInstructions()
    {
        currentScreen = instructions;
    }
    void moveToMainMenu()
    {
        currentScreen = mainMenu;
    }
    void moveToHighScore()
    {
        currentScreen = highScoreScreen;
    }
    void moveToPlay()
    {
        currentScreen = playScreen;
    }
    
    void UpdateScreen()
    {
        if (mainMenu->getInstructionCLick())
        {
            moveToInstructions();
            mainMenu->resetInstructionClick();
        }
        else if (mainMenu->getHighClick())
        {
            moveToHighScore();
            mainMenu->resetHighClick();
        }
        else if (instructions->getClose())
        {
            moveToMainMenu();
            instructions->resetClose();
        }
        else if (highScoreScreen->getClose())
        {            
            
            moveToMainMenu();
            highScoreScreen->resetClose();
        }
        else if (mainMenu->getPlayCLick())
        {
            moveToPlay();
            mainMenu->resetPlayClick();
        }
    }
    void draw() {
        window.clear(Color::Black);
        currentScreen->draw(window);
        window.display();
    }
};





#endif // !SCREENMANAGER_H
