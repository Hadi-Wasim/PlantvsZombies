#ifndef SCREENS_H
#define SCREENS_H

#include <iostream>
#include <SFML/Graphics.hpp>

using namespace sf;
using namespace std;

class Screens {
public:
    virtual ~Screens() {}
    virtual void handleEvents(RenderWindow& window) = 0;
    virtual void draw(RenderWindow& window) = 0;
};



#endif 