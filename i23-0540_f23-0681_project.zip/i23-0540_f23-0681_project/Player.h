#ifndef PLAYER_H
#define PLAYER_H

#include <SFML/Graphics.hpp>
#include <string>
#include <iostream>
using namespace sf;
using namespace std;
class Player {
	string playerName;
	int playerScore;
    RenderWindow window;
    Font font;
    Text inputText1;
    Text inputText2;

    bool isTyping;
public:
    string getName() { return inputText2.getString(); }
    int getScore() { return playerScore; }
    Player() :window(VideoMode(800, 600), "Play Game") {
        playerName = "";
        playerScore = 0;
        isTyping = true;
        if (!font.loadFromFile("Images/assets/fonts/Samdan.ttf")) {
            std::cerr << "Failed to load font\n";
        }

        inputText1.setFont(font);
        inputText1.setCharacterSize(24);
        inputText1.setPosition(10, 10);
        inputText1.setFillColor(sf::Color::Black);
        inputText1.setString("Enter your name:");
        inputText2.setFont(font);
        inputText2.setCharacterSize(24);
        inputText2.setPosition(10, 10);
        inputText2.setFillColor(sf::Color::Black);
       
    }
    void startGame() {
        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                handleEvent(event);
            }

            window.clear(sf::Color::White);
            draw();
            window.display();
        }
    }
    void handleEvent(sf::Event& event) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }
        else if (event.type == sf::Event::TextEntered) {
            if (isTyping) {
                handleTextInput(event.text.unicode);
            }
        }
        else if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Enter && isTyping) {
                isTyping = false;
                (inputText2.getString());
                std::cout << "Player name set to: " << getName() << std::endl;
                window.close();
            }
        }
    }
    void handleTextInput(sf::Uint32 unicode) {
        if (unicode >= 32 && unicode <= 126) { // Only accept printable ASCII characters
            inputText2.setString(inputText2.getString() + static_cast<char>(unicode));
        }
        else if (unicode == 8 && inputText2.getString().getSize() > 0) { // Handle backspace
            inputText2.setString(inputText2.getString().substring(0, inputText2.getString().getSize() - 1));
        }
    }

    void draw() {
        
        window.draw(inputText2);
    }
};






#endif // !PLAYER_H
