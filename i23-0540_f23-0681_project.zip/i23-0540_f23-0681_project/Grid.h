#ifndef GRID_H
#define GRID_H

#include <SFML/Graphics.hpp>

class Grid {
    bool isHighlighted;
    bool hasPlant;
    bool hasZombie;
    RectangleShape shape;
    float x, y, width, height;

public:
    Grid(float startX = 300.0f, float startY = 200.0f, float cellWidth = 90.0f, float cellHeight = 106.0f)
        : isHighlighted(false), hasPlant(false), hasZombie(false), x(startX), y(startY), width(cellWidth), height(cellHeight) {
        shape.setPosition(x, y);
        shape.setSize(Vector2f(width, height));
        
    }

    void draw(RenderWindow& window) {
        if (isHighlighted) {
            shape.setFillColor(Color(255, 255, 255, 100)); // Semi-transparent white for highlight
        }
        else {
            shape.setFillColor(Color(255, 255, 255, 0));
        }
        window.draw(shape);
    }

    
    
    bool contains(float mouseX, float mouseY) const {
        return x <= mouseX && mouseX <= x + width && y <= mouseY && mouseY <= y + height;
    }

    void highlight(bool highlight) {
        isHighlighted = highlight;
    }

    void setPlant(bool hasPlantFlag) {
        hasPlant = hasPlantFlag;
    }

    bool hasPlantOn() const {
        return hasPlant;
    }

    void setZombie(bool hasZombieFlag) {
        hasZombie = hasZombieFlag;
    }

    bool hasZombieOn() const {
        return hasZombie;
    }

    float getX() const {
        return x;
    }

    float getY() const {
        return y;
    }

    float getWidth() const {
        return width;
    }

    float getHeight() const {
        return height;
    }
};

#endif // !GRID_H
