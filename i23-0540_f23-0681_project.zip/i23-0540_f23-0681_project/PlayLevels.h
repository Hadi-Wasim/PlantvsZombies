#ifndef PLAYGAME_H
#define PLAYGAME_H

#include "Player.h"
#include"Screens.h"
#include "ScoreBoard.h"
#include "levels.h"
#include "Grid.h"
#include "Inventory.h"
#include "Sun.h"
#include "Factories.h"
#include <string>
#include <iostream>




class PlayGame : public Screens {
    RenderWindow& window; // Reference to sf::RenderWindow
    Levels* currentLevel;
    ScoreBoard scoreBoard;
    Clock sunTimer;
    Clock test;
    Player* player;
    bool levelSwitched = 0;
    int remainingZombies;
    int lifes = 3;
    unsigned int score;
public:
    ~PlayGame()
    {
        if(currentLevel)
            delete currentLevel;
    }
    PlayGame(RenderWindow& window):window(window)
    {
        score = 0;
        player = new Player;
        player->startGame();
        currentLevel = new Level3(window);    
        remainingZombies = currentLevel->getNumberofZombies();
    }
    struct NameScore {
        string name = "default";
        int scr = 0;
    };
    NameScore a[3];
    void readdata() {
        ifstream ifs("score.txt");
        for (int i = 0; i < 3; i++) {
            ifs >> a[i].name >> a[i].scr;
        }
        ifs.close();
    }
    void dataset() {
        for (int i = 0; i < 3;i++) {
            if (a[i].scr<score) {
               for (int j = i; j < 2;j++) {
                    a[j] = a[j+1];
                }
                a[i].name = player->getName();
                a[i].scr = score;
                break;
            }
        }
    }
    
    void writescore() {
        dataset();
        ofstream ofs("score.txt",ios::trunc);
        for (int i = 0; i < 3;i++) {
            ofs << a[i].name << " " << a[i].scr;

        }
        ofs.close();
    }

    void changeLevel()
    {
        if (test.getElapsedTime().asSeconds() > 4 && !levelSwitched)
        {
            delete currentLevel;
            currentLevel = new Level2(window);
            levelSwitched = true;
        }
    }
    void handleEvents(RenderWindow& window) override {
        scoreBoard.updateScore(0);
        int mouseX = Mouse::getPosition(window).x;
        int mouseY = Mouse::getPosition(window).y;


        
        
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (currentLevel->getGrid()[i][j].contains(static_cast<float>(mouseX), static_cast<float>(mouseY))) {
                    currentLevel->getGrid()[i][j].highlight(true);
                }
                else {
                    currentLevel->getGrid()[i][j].highlight(false);
                }
            }
        }
        if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
            // Check if a card is being dragged
            PlantCard* draggedCard = currentLevel->getInventory()->getDraggedCard(mouseX, mouseY);
            if (draggedCard) {
                // Update the dragged card's position
                currentLevel->getInventory()->updateDraggedCardPosition(mouseX, mouseY);
            }
        }
        else {
            // End dragging if mouse button released
            for (int i = 0; i < currentLevel->getInventory()->getNumSlots(); i++) {
                if (currentLevel->getInventory()->getPlantCard(i).isBeingDragged) {
                    // Check if the drop location is valid (e.g., over a grid cell)
                    bool isValidDrop = false;
                    for (int j = 0; j < 5; j++) {
                        for (int k = 0; k < 9; k++) {
                            if (currentLevel->getGrid()[j][k].contains(mouseX, mouseY) && !currentLevel->getGrid()[j][k].hasPlantOn() && currentLevel->getInventory()->getPlantCard(i).getPrice() <= currentLevel->getSun().getSunPoints()) {
                                isValidDrop = true;
                                currentLevel->getSun().setSunPoints(currentLevel->getSun().getSunPoints() - currentLevel->getInventory()->getPlantCard(i).getPrice());
                                cout << "Plant of type: " << currentLevel->getInventory()->getPlantCard(i).plantId << " is created successfully. card returning back to org position" << endl;
                                currentLevel->getGrid()[j][k].setPlant(true); // Example: mark the grid cell as occupied
                                currentLevel->identifyCard(i);
                                currentLevel->getPlantFactory()[currentLevel->getCurrentPlantNum()]->createPlant(window, currentLevel->getGrid()[j][k].getX() + 20, currentLevel->getGrid()[j][k].getY() + 20);
                                currentLevel->setCurrentPlantNum(currentLevel->getCurrentPlantNum() + 1);
                                //real plant should be created at this location and this should be moved to it's original location
                                currentLevel->getInventory()->getPlantCard(i).plantSprite.setPosition(currentLevel->getInventory()->getPlantCard(i).originalX, currentLevel->getInventory()->getPlantCard(i).originalY);
                                break;
                            }
                        }
                        if (isValidDrop) {
                            break;
                        }
                    }

                    if (!isValidDrop) {
                        // Move the card back to its original position
                        currentLevel->getInventory()->getPlantCard(i).plantSprite.setPosition(currentLevel->getInventory()->getPlantCard(i).originalX, currentLevel->getInventory()->getPlantCard(i).originalY);
                    }

                    currentLevel->getInventory()->getPlantCard(i).endDrag();
                    break; // Only handle one dragged card at a time
                }
            }
        }

        if (sunTimer.getElapsedTime().asSeconds() >= 3)
        {
            sunTimer.restart();
            currentLevel->getSun().spawn(0);
        }
        currentLevel->getSun().update();
        currentLevel->getSun().isClicked(window);
        for (int i = 0; i < currentLevel->getCurrentPlantNum(); i++)
        {
            if (currentLevel->getPlantFactory()[i])
                currentLevel->getPlantFactory()[i]->getPlant()->updateScreen();

        }
        currentLevel->initZombiesMovement();
        for (int i = 0; i < currentLevel->getNumberofZombies(); i++)
        {
            if (currentLevel->getZombieFactory()[i])
            {
                currentLevel->getZombieFactory()[i]->getZombie()->updateScreen();
                if (currentLevel->getZombieFactory()[i]->getZombie()->getZombieSprite().getPosition().x <= 20 && currentLevel->getZombieFactory()[i]->getZombie()->getHealth())
                {
                    currentLevel->getZombieFactory()[i]->getZombie()->setHealth(0);
                    lifes--;
                    break;
                }


            }
        }
        
        for (int i = 0; i < currentLevel->getNumberofZombies(); i++)
        {
            bool isPlantKilled = false; // Flag to track if the plant is killed by any zombie
            for (int j = 0; j < currentLevel->getCurrentPlantNum(); j++)
            {
                if (currentLevel->getZombieFactory()[i]->getZombie()->getZombieSprite().getGlobalBounds().intersects(currentLevel->getPlantFactory()[j]->getPlant()->getPlantSprite().getGlobalBounds()) && currentLevel->getPlantFactory()[j]->getPlant()->getHealth() > 0)
                {
                    currentLevel->getZombieFactory()[i]->getZombie()->attackPlant(currentLevel->getPlantFactory()[j]->getPlant());
                    isPlantKilled = true; // Set the flag if any plant is killed
                 
                }
                // Check if any plant is killed by this zombie
                if (isPlantKilled && currentLevel->getPlantFactory()[j]->getPlant()->getHealth())
                {
                    for (int k = 0; k < 5; k++)
                    {
                        for (int l = 0; l < 9; l++)
                        {
                            if (currentLevel->getGrid()[k][l].contains(currentLevel->getPlantFactory()[j]->getPlant()->getPlantSprite().getPosition().x, currentLevel->getPlantFactory()[j]->getPlant()->getPlantSprite().getPosition().y))
                                currentLevel->getGrid()[k][l].setPlant(0);
                        }
                    }
                       currentLevel->getZombieFactory()[i]->getZombie()->stopMoving(); // Stop movement if a plant is killed
                }
                else
                {
                    currentLevel->getZombieFactory()[i]->getZombie()->startMoving(); // Otherwise, resume movement
                }
            }

            
        }

        for (int i = 0; i < currentLevel->getNumberofZombies(); i++) {
            for (int j = 0; j < currentLevel->getCurrentPlantNum(); j++) {
                if (currentLevel->getZombieFactory()[i]->getZombie()->getZombieSprite().getGlobalBounds().intersects(currentLevel->getPlantFactory()[j]->getPlant()->getPlantSprite().getGlobalBounds())) {
                    // Collision detected between zombie and plant

                    if (currentLevel->getPlantFactory()[j]->getPlant()->getPlantId() == "wallNut") {
                        // Set wallnut movement direction based on collision
                        currentLevel->getZombieFactory()[i]->getZombie()->setHealth(0);
                        
                        // Update wallnut position
                        WallNut* wn = dynamic_cast<WallNut*>(currentLevel->getPlantFactory()[j]->getPlant());
                        wn->setDirection(-1);

                    }
                }
            }
        }
        for (int i = 0; i < currentLevel->getCurrentPlantNum(); i++)
        {
            
           if(currentLevel->getPlantFactory()[i]->getPlant()->getPlantId() == "peaShooter")
            {

                PeaShooter* peaPtr = dynamic_cast<PeaShooter*>(currentLevel->getPlantFactory()[i]->getPlant());
                for (int j = 0; j < currentLevel->getNumberofZombies(); j++)
                {
                    if (peaPtr->checkColision(currentLevel->getZombieFactory()[j]->getZombie()->getZombieSprite(), currentLevel->getZombieFactory()[j]->getZombie()->getHealth()))
                    {
                        
                        currentLevel->getZombieFactory()[j]->getZombie()->getDamage();
                        if (!(currentLevel->getZombieFactory()[j]->getZombie()->getHealth()))
                        {
                            score += currentLevel->getZombieFactory()[j]->getZombie()->getKillScore();
                            remainingZombies--;
                            break;
                        }
                    }
                }
                
            }
        }

        if (!lifes)
        {

            readdata();
            writescore();
            cout << "you lost";
            window.close();
        }
        
        switchLevel();
        switchLevel2();

    }
    void switchLevel()
    {

        if (!remainingZombies && !levelSwitched)
        {
            readdata();
            writescore();
            delete currentLevel;
            currentLevel = new Level2(window);
            levelSwitched = true;
        }
    }
    void switchLevel2()
    {

        if (!remainingZombies && levelSwitched)
        {
            readdata();
            writescore();
            delete currentLevel;
            currentLevel = new Level3(window);
            levelSwitched = true;
        }
    }
    
    void draw(RenderWindow& window) override {
        
            scoreBoard.updateScore(score);
            currentLevel->draw(window);
            scoreBoard.draw(window);
        
    }

};



#endif // !PLAYLEVELS_H
