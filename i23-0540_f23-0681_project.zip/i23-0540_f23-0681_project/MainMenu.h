#ifndef MAINMENU_H
#define MAINMENU_H

#include "Screens.h"

class MainMenu :public Screens
{
    RenderWindow& window;
    Texture PlayButtonTexture;
    Texture InstructionsButtonTexture;
    Sprite PlayButton;
    Sprite InstructionsButton;
    Image backgroundImage;
    Texture backgroundTexture;
    Sprite background;
    bool isInstructionClicked;
    Texture HighScoreButtonTexture;
    Sprite HighScoreButton;
    bool isHighScoreClicked;
    bool isPlayClicked;


    void setupButtons() {
        PlayButtonTexture.loadFromFile("Images/startButtonrs.png");
        InstructionsButtonTexture.loadFromFile("Images/Instructionsrs.png");

        PlayButton.setTexture(PlayButtonTexture);
        InstructionsButton.setTexture(InstructionsButtonTexture);

        HighScoreButtonTexture.loadFromFile("Images/highscorebuttonrs.png");
        HighScoreButton.setTexture(HighScoreButtonTexture);

        // Position and size adjustments for the buttons
        PlayButton.setPosition(740, 355);
        InstructionsButton.setPosition(736, 520);
        HighScoreButton.setPosition(740, 680);

    }
    void setupBG() {
        backgroundImage.loadFromFile("Images/MainMenuorg.jpg");
        backgroundTexture.loadFromImage(backgroundImage);

        background.setTexture(backgroundTexture);
        background.setPosition(0, 0);
    }

public:


    MainMenu(RenderWindow& window) :window(window)
    {
        isInstructionClicked = 0;
        isHighScoreClicked = 0;
        isPlayClicked = 0;

        setupButtons();
        setupBG();
    }
    void handleEvents(sf::RenderWindow& window) override
    {
        if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
            int mouseX = sf::Mouse::getPosition(window).x;
            int mouseY = sf::Mouse::getPosition(window).y;
            if (PlayButton.getGlobalBounds().contains(mouseX, mouseY)) {
                cout << "Play button clicked!" << endl;
                isPlayClicked = 1;


                // Switch to gameplay screen
            }
            else if (InstructionsButton.getGlobalBounds().contains(mouseX, mouseY)) {
                cout << "Instructions button clicked!" << endl;
                isInstructionClicked = 1;
                // Switch to instructions screen
            }
            else if (HighScoreButton.getGlobalBounds().contains(mouseX, mouseY)) {
                cout << "HighScore button clicked!" << endl;
                isHighScoreClicked = 1;
                // Switch to instructions screen
            }
            // Add more button checks as needed
        }

    }

    bool getPlayCLick() { return isPlayClicked; }
    void resetPlayClick() { isPlayClicked = 0; }
    
    bool getInstructionCLick() { return isInstructionClicked; }
    void resetInstructionClick() { isInstructionClicked = 0; }

    bool getHighClick() { return isHighScoreClicked; }
    void resetHighClick() { isHighScoreClicked = 0; }

    void draw(sf::RenderWindow& window) override
    {
        window.draw(background);
        window.draw(PlayButton);
        window.draw(HighScoreButton);
        window.draw(InstructionsButton);
    }
};

#endif // !MAINMENU_H
