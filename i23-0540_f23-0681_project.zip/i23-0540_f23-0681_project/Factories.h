#ifndef FACTORIES_H
#define FACTORIES_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include "Sun.h"

using namespace sf;
using namespace std;

class Pea {
private:
    Sprite peaSprite;
    bool isPeaActive;
    float peaSpeed;
    Texture peaTexture;
    int damage;

public:
    Pea() {
        peaTexture.loadFromFile("Images/pea.png");
        peaSprite.setTexture(peaTexture);
        isPeaActive = false;
        peaSpeed = 1;
        damage = 1;
    }

    void activate(float startX, float startY) {
        peaSprite.setPosition(startX, startY);
        isPeaActive = true;
    }
    void setSprite(Texture pea) {
        peaSprite.setTexture(pea);
    }

    void updatePea() {
        if (isPeaActive) {
            peaSprite.setPosition(peaSprite.getPosition().x + peaSpeed, peaSprite.getPosition().y);
            if (peaSprite.getPosition().x > 1220) {
                isPeaActive = false;
            }
        }
    }

    void draw(RenderWindow& window) {
        if (isPeaActive) {
            window.draw(peaSprite);
        }
    }

    bool isActive() {
        return isPeaActive;
    }

    void deactivatePea() {
        isPeaActive = false;
    }

    Sprite getPeaSprite() { return peaSprite; }
};






class Plant {
protected:
    string plantId;
    int healthPoint;
    Sprite plantSprite;
    Texture plantTexture;
    int price;
    Clock animationClock; // Clock to manage frame switching
    bool isAlive = true;


public:
    string getPlantId() { return plantId; }
    int getHealth() { return healthPoint; }
    void setHealth(int hp) { healthPoint = hp; }
    int getPrice() { return price; }
    void checkLife()
    {
        if (healthPoint == 0)
        {
            isAlive = false;
         
        }
        
    }

    void getDamage(int n) { healthPoint -= n; }
    virtual void updateScreen() = 0;
    virtual void draw(RenderWindow& window) = 0;

    Sprite getPlantSprite() { return plantSprite; }

    virtual ~Plant() {} // Virtual destructor

};




class SnowPea :public Plant {
    Clock shootTimer;
    int frameWidth;
    int frameHeight;
    int currentFrame;
    Texture ptex;
    Pea pea;
    bool isActive;
public:
    SnowPea(int x, int y) {
        plantTexture.loadFromFile("Images/snowpea.png");
        plantSprite.setTexture(plantTexture);
        ptex.loadFromFile("Images/icepea.png");
        pea.setSprite(ptex);
        frameWidth = 71; // Correct frame width based on the dimensions
        frameHeight = 71; // The height of the sprite
        currentFrame = 0;
        price = 150;

        setTextureRect(currentFrame);
        plantSprite.setPosition(x, y);
    }
    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        plantSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }
    void Shoot() {
        if (shootTimer.getElapsedTime().asSeconds() > 5 && isActive) {
            pea.activate(plantSprite.getPosition().x, plantSprite.getPosition().y);
            shootTimer.restart();
        }
    }
    void updateScreen() override {
        Shoot();
        pea.updatePea();

        // Update animation frame every 0.1 seconds
        if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
            currentFrame = (currentFrame + 1) % 15; // There are 13 frames, loop back to 0 after the last frame
            setTextureRect(currentFrame);
            animationClock.restart(); // Reset the clock
        }
    }

    void draw(RenderWindow& window) override {
        window.draw(plantSprite);
        pea.draw(window);
    }

};






class CherryBomb : public Plant {
private:
    bool isWithinRange(const FloatRect& rect, float rangeX, float rangeY) {
        FloatRect explosionArea(plantSprite.getPosition().x - rangeX, plantSprite.getPosition().y - rangeY, rangeX * 2, rangeY * 2);
        return explosionArea.intersects(rect);
    }
    Clock explosionTimer;
    int frameWidth;
    int frameHeight;
    int currentFrame;
    bool exploded;

public:
    CherryBomb(int x, int y) {
        plantTexture.loadFromFile("Images/cherrybomb.png");
        plantSprite.setTexture(plantTexture);
        frameWidth = 71;
        frameHeight = 71;
        currentFrame = 0;
        price = 150;
        isAlive = true;

        setTextureRect(currentFrame);
        plantSprite.setPosition(x, y);


    }








    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        plantSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }


    void updateScreen() override {
        if (animationClock.getElapsedTime().asSeconds() > 0.3f) {
            currentFrame = (currentFrame + 1) % 7; // There are 13 frames, loop back to 0 after the last frame
            setTextureRect(currentFrame);
            animationClock.restart(); // Reset the clock
        }
        if (currentFrame = 7)
            isAlive = false;

    }

    void draw(RenderWindow& window) override {
        if(isAlive)
            window.draw(plantSprite);
            
    }


};



class Repeater : public Plant {
    Clock shootTimer;
    Clock shootTimer1;
    float frameWidth;
    int frameHeight;
    int currentFrame;
    Pea pea;
    Pea pea1;

public:
    Repeater(int x, int y) {
        plantTexture.loadFromFile("Images/repeaters.png");
        plantSprite.setTexture(plantTexture);
        frameWidth = 72.8; // Correct frame width based on the dimensions
        frameHeight = 71; // The height of the sprite
        currentFrame = 0;
        price = 150;

        setTextureRect(currentFrame);
        plantSprite.setPosition(x, y);
    }

    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        plantSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }

    void Shoot() {
        if (shootTimer.getElapsedTime().asSeconds() > 5) {
            pea.activate(plantSprite.getPosition().x, plantSprite.getPosition().y);
            shootTimer.restart();
        }
        if (shootTimer1.getElapsedTime().asSeconds() > 5.1) {
            pea1.activate(plantSprite.getPosition().x, plantSprite.getPosition().y);
            shootTimer.restart();
        }
    }
    void updateScreen() override {
        Shoot();
        pea.updatePea();

        // Update animation frame every 0.1 seconds
        if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
            currentFrame = (currentFrame + 1) % 15; // There are 13 frames, loop back to 0 after the last frame
            setTextureRect(currentFrame);
            animationClock.restart(); // Reset the clock
        }
    }

    void draw(RenderWindow& window) override {
        window.draw(plantSprite);
        pea.draw(window);
    }
};




class SunFlower : public Plant {
    Clock SunTimer;
    int frameWidth;
    int frameHeight;
    int currentFrame;
    Sun sun;
    RenderWindow& window;

public:
    SunFlower(RenderWindow& window,int x, int y):sun(window,true),window(window) {
        plantTexture.loadFromFile("Images/sunflower.png");
        plantSprite.setTexture(plantTexture);
        frameWidth = 71; // Correct frame width based on the dimensions
        frameHeight = 71; // The height of the sprite
        currentFrame = 0;
        plantId = "sunFlower";
        price = 150;
        healthPoint = 3;
        setTextureRect(currentFrame);
        plantSprite.setPosition(x, y);
    }
    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        plantSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }

    void spawnSun(Sun& sun) {
        if (SunTimer.getElapsedTime().asSeconds() >= 4.0) {
            SunTimer.restart();
            // Spawn sun at the position of the Sunflower, passing true to indicate it's a static sun
            sun.spawnStatic(plantSprite.getPosition().x, plantSprite.getPosition().y);
        }
    }
    void updateScreen() override 
    {
        checkLife();
        // Update animation frame every 0.1 seconds
            if (isAlive)
                {
                if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
                    currentFrame = (currentFrame + 1) % 17; // There are 13 frames, loop back to 0 after the last frame
                    setTextureRect(currentFrame);
                    animationClock.restart(); // Reset the clock
                }
                spawnSun(sun);
                sun.isClicked(window);
            }
    }
    void draw(RenderWindow& window) override {
      if(isAlive)
      {
          window.draw(plantSprite);
          sun.draw(window);
      }
    }
};
class PeaShooter : public Plant {
    Clock shootTimer;
    int frameWidth;
    int frameHeight;
    int currentFrame;
    Pea pea;
    bool isActive;
public:
    PeaShooter(int x , int y) {
        plantTexture.loadFromFile("Images/peashooter.png");
        plantSprite.setTexture(plantTexture);
        frameWidth = 71; // Correct frame width based on the dimensions
        frameHeight = 71; // The height of the sprite
        currentFrame = 0;
        price = 100;
        plantId = "peaShooter";
        healthPoint = 3;
        setTextureRect(currentFrame);
        plantSprite.setPosition(x, y);
    }

    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        plantSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }

    Pea getPea() { return pea; }
    bool checkColision(Sprite zombie, int health)
    {
        if (pea.getPeaSprite().getGlobalBounds().intersects(zombie.getGlobalBounds()) && pea.isActive() && health)
        {
            pea.deactivatePea();
            return true;
        }
        return false;
    }
    void Shoot(){
        if (shootTimer.getElapsedTime().asSeconds() > 2 && isActive) {
            pea.activate(plantSprite.getPosition().x, plantSprite.getPosition().y);
            shootTimer.restart();
        }
    }
    void updateScreen() override {
        checkLife();
        if (isAlive)
        {
            Shoot();
            pea.updatePea();

            // Update animation frame every 0.1 seconds
            if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
                currentFrame = (currentFrame + 1) % 13; // There are 13 frames, loop back to 0 after the last frame
                setTextureRect(currentFrame);
                animationClock.restart(); // Reset the clock
            }
        }
    }

    void draw(RenderWindow& window) override {
        if (isAlive)
        {
            window.draw(plantSprite);
            pea.draw(window);
        }
    }
};

class WallNut : public Plant {
private:
    bool isRolling = true;
    int frameWidth;
    int frameHeight;
    int currentFrame;
    int direction;

public:
    WallNut(int x, int y) {
        plantId = "wallNut";
        plantTexture.loadFromFile("Images/wallnut.png");
        plantSprite.setTexture(plantTexture);
        frameWidth = 71; // Correct frame width based on the dimensions
        frameHeight = 71; // The height of the sprite
        currentFrame = 0;
        price = 50;
        direction = 0;

        setTextureRect(currentFrame);
        plantSprite.setPosition(x, y);
    }
    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        plantSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }
    void setDirection(int x) { direction = x; }

    void updateScreen() override {
        if (isRolling) {
            // Calculate the distance to move based on a fixed speed
            float speed = 25.0f;
            float deltaTime = 1.0f / 60.0f;
            if (plantSprite.getPosition().y <= 205 || plantSprite.getPosition().y >= 630) {
                // Reverse direction
                direction = -direction;
            }
            // Update the position along the x-axis
            sf::Vector2f currentPosition = plantSprite.getPosition();
            sf::Vector2f newPosition = sf::Vector2f(currentPosition.x + speed * deltaTime, currentPosition.y + direction);
            plantSprite.setPosition(newPosition);

            // Update animation frame every 0.1 seconds
            if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
                currentFrame = (currentFrame + 1) % 4; // There are 13 frames, loop back to 0 after the last frame
                setTextureRect(currentFrame);
                animationClock.restart(); // Reset the clock
            }


            if (newPosition.x > 1200) {
                isRolling = false;
            }
        }
    }
    void draw(RenderWindow& window) override {
        window.draw(plantSprite);
    }


};


class PlantFactory {
protected:
    Plant* plant;

public:
    virtual void createPlant(RenderWindow& window,int x, int y) = 0;
    virtual Plant* getPlant() {
        return plant;
    }
    virtual ~PlantFactory() {} // Virtual destructor

};


class PeaShooterFactory :public PlantFactory
{
public:

    virtual void createPlant(RenderWindow& window,int Xcoord, int Ycoord) override {
        plant = new PeaShooter(Xcoord,Ycoord);
    }
    
};


class CherryBombFactory :public PlantFactory
{
public:

    virtual void createPlant(RenderWindow& window, int Xcoord, int Ycoord) override {
        plant = new CherryBomb(Xcoord, Ycoord);
    }

};


class RepeaterFactory :public PlantFactory
{
public:

    virtual void createPlant(RenderWindow& window, int Xcoord, int Ycoord) override {
        plant = new Repeater(Xcoord, Ycoord);
    }

};



class SnowPeaFactory : public PlantFactory
{
public:
    virtual void createPlant(RenderWindow& window, int Xcoord, int Ycoord) override {
        plant = new SnowPea(Xcoord, Ycoord);
    }
};

class SunFlowerFactory : public PlantFactory
{
public:
    virtual void createPlant(RenderWindow& window,int Xcoord, int Ycoord) override {
        plant = new SunFlower(window,Xcoord,Ycoord);
    }
};

class wallNutFactory : public PlantFactory
{
public:
    virtual void createPlant(RenderWindow& window, int Xcoord, int Ycoord) override {

        plant = new WallNut(Xcoord, Ycoord);
    }
};





// Interface for creating zombies
class Zombie {
protected:
    string zombieId;
    int healthPoint;
    Sprite zombieSprite;
    Texture zombieTexture;
    int damage = 1;
    Clock animationClock;
    bool isMoving;
    int frameWidth;
    int frameHeight;
    int currentFrame;
    int direction;
    RenderWindow& window;
    float moveDelay;
    Clock moveClock;
    bool isAlive;
    Clock DamageClock;
    int killScore;
    

public:
    string getZombieId() { return zombieId; }
    int getHealth() { return healthPoint; }
    void setHealth(int hp) { healthPoint = hp; }   
    void getDamage() { healthPoint --; }
    void attackPlant(Plant* plant) {
        if (isAlive && DamageClock.getElapsedTime().asSeconds() >= 2) {
            DamageClock.restart();
            plant->getDamage(damage);
        }
    }
    int getKillScore() { return killScore; }
    
    bool getIsMoving() { return isMoving; }
    void startMoving() { isMoving = true; }
    void stopMoving() { isMoving = false; }

    void setMoveDelay(float delay) { moveDelay = delay; }
    float getMoveDelay() { return moveDelay; }

    Sprite getZombieSprite() { return zombieSprite; }

    virtual void updateScreen() = 0;
    virtual void draw(RenderWindow& window) = 0;
    Zombie(RenderWindow& win) : window(win) { killScore = 0; } // Initialize window in the base class constructor
    virtual ~Zombie() {} // Virtual destructor
};

class SimpleZombie : public Zombie {
    
public:
    SimpleZombie(RenderWindow& window,int x ,int y): Zombie(window) {
        zombieTexture.loadFromFile("Images/zomb.png");
        frameWidth = 96; // Correct frame width based on the dimensions
        frameHeight = 120; // The height of the sprite
        currentFrame = 0;
        zombieSprite.setTexture(zombieTexture);
        setTextureRect(currentFrame);
        zombieSprite.setPosition(x, y);
        healthPoint = 3;
        isMoving = false;
        isAlive = true;
        direction = 1;
        damage = 1;
        killScore = 3;
    }

    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        zombieSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }

    
    virtual void updateScreen()override {
        if (healthPoint)
        {
            if (isMoving)
            {
                if (direction)
                    zombieSprite.setPosition(zombieSprite.getPosition().x - 0.1, zombieSprite.getPosition().y);
                else
                    zombieSprite.setPosition(zombieSprite.getPosition().x + 0.1, zombieSprite.getPosition().y);
            }
            if (zombieSprite.getPosition().x < 0)
                isMoving = false;
            if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
                currentFrame = (currentFrame + 1) % 20; // There are 22 frames, loop back to 0 after the last frame
                setTextureRect(currentFrame);
                animationClock.restart(); // Reset the clock
            }
            isAlive = true;
        }
        else
            isAlive = false;
    }
    virtual void draw(RenderWindow& window)override {
       if(isAlive)
           window.draw(zombieSprite);
    }

    

};
class FootballZombie :public Zombie {
    float horizontalSpeed;
    Clock directionClock;
public:
    
    FootballZombie(RenderWindow& window, int x, int y) : Zombie(window) {
        zombieTexture.loadFromFile("Images/football.png");
        frameWidth = 160; // Correct frame width based on the dimensions
        frameHeight = 160; // The height of the sprite
        currentFrame = 0;
        zombieSprite.setTexture(zombieTexture);
        setTextureRect(currentFrame);
        zombieSprite.setPosition(x, y);
        healthPoint = 2;
        horizontalSpeed = 0.1; // Units per second
        
        isAlive = true;
        isMoving = false;
        direction = 1;
        damage = 2;
        killScore = 10;
    }

    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        zombieSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }

    virtual void updateScreen()override 
    {
        if(healthPoint)
        {

            if (isMoving)
            {

               

                // Update position based on direction and time
                if (moveClock.getElapsedTime().asSeconds() >= moveDelay) {
                    moveClock.restart(); // Restart the clock for the next movement
                    if (zombieSprite.getPosition().y > 629)
                        direction = 1;
                    else if (zombieSprite.getPosition().y < 200)
                        direction = 2;
                    // Horizontal movement
                    if (direction == 0) {
                        zombieSprite.setPosition(zombieSprite.getPosition().x - horizontalSpeed, zombieSprite.getPosition().y);
                    }
                    else if (direction == 2) {
                        zombieSprite.setPosition(zombieSprite.getPosition().x, zombieSprite.getPosition().y + horizontalSpeed);
                    }

                    // Vertical movement
                    if (direction == 1) {
                        zombieSprite.setPosition(zombieSprite.getPosition().x, zombieSprite.getPosition().y - horizontalSpeed);
                    }

                    // Update direction after a certain time
                    if (directionClock.getElapsedTime().asSeconds() >= 4.0f) {
                        direction = (direction + 1) % 3;    // Cycle through directions (0: left, 1: right, 2: up, 3: down)

                        directionClock.restart(); // Restart animation clock for the next direction change
                    }
                    if (zombieSprite.getPosition().x < 0)
                        isMoving = false;
                    if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
                        currentFrame = (currentFrame + 1) % 4; // There are 22 frames, loop back to 0 after the last frame
                        setTextureRect(currentFrame);
                        animationClock.restart(); // Reset the clock
                    }
                }
                isAlive = true;
            }
        }
        else
            isAlive = false;

            // Check if the zombie leaves the screen
            if (zombieSprite.getPosition().x < -zombieSprite.getGlobalBounds().width ||
                zombieSprite.getPosition().y < -zombieSprite.getGlobalBounds().height ||
                zombieSprite.getPosition().y > 800) {
                isAlive = false;
            }
            
        
    }


    virtual void draw(RenderWindow& window)override {
        if(isAlive)
            window.draw(zombieSprite);
    }
};

class FlyingZombie :public Zombie {
public:
    
    FlyingZombie(RenderWindow& window, int x, int y) : Zombie(window) {
        zombieTexture.loadFromFile("Images/Flying.png");
        frameWidth = 80; // Correct frame width based on the dimensions
        frameHeight = 124; // The height of the sprite
        currentFrame = 0;
        zombieSprite.setTexture(zombieTexture);
        setTextureRect(currentFrame);
        zombieSprite.setPosition(x, y);
        int health = 3;
        isMoving = false;
        direction = 1;
        isAlive = true;
    }

    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        zombieSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }


    virtual void updateScreen()override {
        if (healthPoint)
        {
            if (isMoving)
            {
                // Move towards left
                zombieSprite.setPosition(zombieSprite.getPosition().x - 0.1, zombieSprite.getPosition().y);

                // Check if the zombie leaves the screen
                if (zombieSprite.getPosition().x < 0)
                    isMoving = false;
                if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
                    currentFrame = (currentFrame + 1) % 4; // There are 22 frames, loop back to 0 after the last frame
                    setTextureRect(currentFrame);
                    animationClock.restart(); // Reset the clock
                }
            }
        }
        else
            isAlive = false;
    }

    virtual void draw(RenderWindow& window)override {
        if(isAlive)
            window.draw(zombieSprite);
    }
};
class DancingZombie :public Zombie {
float Speed;
bool movingUp;
bool movingRight;
Clock moveClock;
int dir;

public:

    DancingZombie(RenderWindow& window, int x, int y) : Zombie(window) {
        zombieTexture.loadFromFile("Images/dancing.png");
        frameWidth = 130; // Correct frame width based on the dimensions
        frameHeight = 130; // The height of the sprite
        currentFrame = 0;
        zombieSprite.setTexture(zombieTexture);
        setTextureRect(currentFrame);
        zombieSprite.setPosition(x, y);
        healthPoint = 3;
        isAlive = true;
        Speed = 0.1;
        movingRight = false;
        movingUp = false;
        dir = -1;
        
    }

    void setTextureRect(int frame) {
        int textureX = frame * frameWidth;
        int textureY = 0; // Assuming Y offset is 0 if your sprite sheet is only one row
        zombieSprite.setTextureRect(IntRect(textureX, textureY, frameWidth, frameHeight));
    }



    void updateScreen() override {
        if (healthPoint && isMoving) {
            float SpeedX = 0.1f; // Constant horizontal speed
            float SpeedY = 0.1f; // Constant vertical speed

            // Update vertical position and check for boundary reversal
            if (zombieSprite.getPosition().y <= 205 || zombieSprite.getPosition().y >= 630) {
                 // Reverse direction
                dir = -dir;
            }

            // Update sprite position based on speed
            zombieSprite.setPosition(zombieSprite.getPosition().x - SpeedX, zombieSprite.getPosition().y + SpeedY*dir);

            // Check if the zombie leaves the screen
            if (zombieSprite.getPosition().x < 0) {
                isMoving = false; // Stop moving
            }

            // Animation logic (if needed)
            if (animationClock.getElapsedTime().asSeconds() > 0.1f) {
                currentFrame = (currentFrame + 1) % 4; // Loop animation frames
                setTextureRect(currentFrame);
                animationClock.restart(); // Reset the animation clock
            }
        }
        else
            isAlive = false;
    }

    virtual void draw(RenderWindow& window)override {
        if(isAlive)
            window.draw(zombieSprite);
    }
};



class ZombieFactory {
protected:
    Zombie* zombie;
public:
    virtual void createZombie(RenderWindow& window, int x, int y) = 0;
    virtual Zombie* getZombie() { return zombie; }
    virtual ~ZombieFactory(){}
};
class FootballZombieFactory : public ZombieFactory {
    virtual void createZombie(RenderWindow& window, int x, int y) override {
        zombie = new FootballZombie(window, x, y);
        cout << "footballzombie created\n";
    }
};
class SimpleZombieFactory : public ZombieFactory{
    virtual void createZombie(RenderWindow& window, int x, int y) override {
        zombie = new SimpleZombie(window,x,y);
        cout << "simplezombie created\n";
    }

};

class FlyingZombieFactory : public ZombieFactory {
    virtual void createZombie(RenderWindow& window, int x, int y) override {
        zombie = new FlyingZombie(window, x, y);
        cout << "flyingzombie created\n";
    }

};



class DancingZombieFactory : public ZombieFactory {
    virtual void createZombie(RenderWindow& window, int x, int y) override {
        zombie = new DancingZombie(window, x, y);
        cout << "dancingzombie created\n";
    }

};

#endif // !FACTORIES_H
