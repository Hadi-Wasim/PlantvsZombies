﻿#include "MainMenu.h"
#include "InstructionMenu.h"
#include "Screens.h"
#include "ScreenManager.h"
#include "Mouse.h"

int main()
{




    sf::Texture texture;
    if (!texture.loadFromFile("Images/pause.png")) {
        return -1;  // Handle error
    }

    sf::Sprite sprite;
    sprite.setTexture(texture);
    RenderWindow window(VideoMode(1600, 914), "Plants Vs Zombies");


    sf::Texture resumeButtonTexture;
    if (!resumeButtonTexture.loadFromFile("Images/resumee.png")) {
        return -1;  // Handle error if the file is not found
    }

    sf::Sprite resumeButtonSprite;

    resumeButtonSprite.setTexture(resumeButtonTexture);
    // Set the position to the center of the window
    resumeButtonSprite.setPosition(
        (window.getSize().x - resumeButtonSprite.getLocalBounds().width) / 2,
        (window.getSize().y - resumeButtonSprite.getLocalBounds().height) / 2
    );


    // Game icon
    Image icon;
    if (!icon.loadFromFile("Images/icon.png")) {
        return 1;
    }
    window.setIcon(32, 32, icon.getPixelsPtr());






    Clock timeMoney;
    Clock clock;
    MouseEvents m(window);
    ScreenManager screenManager(window);

    bool paused = false; // Variable to track if the game is paused
    
    while (window.isOpen())
    {
        float time = clock.getElapsedTime().asMicroseconds();
        clock.restart();
        time = time / 800;


        sf::Sprite pauseButtonSprite;
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }

            // Pause the game when spacebar is pressed
            if (event.type == Event::KeyPressed && event.key.code == Keyboard::Space) {
                paused = !paused; // Toggle pause state
            }
            if (resumeButtonSprite.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
                paused = false;
            }

        }

        // If the game is paused, handle events and draw the Paus
        if (paused) {


            window.clear();
            window.draw(sprite);
            window.draw(resumeButtonSprite);
            window.display();
        }

        if (!paused) {
            // Handle mouse events if the game is not paused
            m.handleEvents(window);

            // Update screen based on mouse events
            screenManager.handleEvents();
            screenManager.UpdateScreen();
            screenManager.draw();
        }
    }

    return 0;
}
