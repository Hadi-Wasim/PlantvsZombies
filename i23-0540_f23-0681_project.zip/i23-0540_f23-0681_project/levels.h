#ifndef LEVELS_H
#define LEVELS_H

#include <SFML/Graphics.hpp>
#include "Factories.h"
#include "Grid.h"
#include "Inventory.h"
#include "Sun.h"
#include "Factories.h"


class Levels {
protected:
       RenderWindow& window; // Reference to sf::RenderWindow
       Texture backgroundTexture;
       Sprite background;
       Grid** grid;
       Sun sun;
       Inventory* inventory;
       bool isMousePressed;
       Clock levelTimer;
       PlantFactory** plantFactory;
       ZombieFactory** zombieFactory;
       string* unlockedPlants;
       string* unlockedZombies;
       int currentPlantNum;
       int totalNumberofPlants;
       int NumberofZombies;
       int waveTime = 7;
       int numberOfZombiesInAWave = 1;
       
public:
    // Virtual methods for polymorphism


    virtual ~Levels() {} // Virtual destructor for polymorphism
    virtual int Duration() = 0;
    virtual int getLevelNumber() = 0;
    virtual int getWaveCount() = 0;
    virtual void identifyCard(int i) = 0;
    virtual void draw(RenderWindow& window) = 0;
    virtual void spawnZombies() = 0;

    RenderWindow& getWindow() { return window; }
    Texture& getBackgroundTexture() { return backgroundTexture; }
    Sprite& getBackground() { return background; }
    Grid** getGrid() { return grid; }
    Sun& getSun() { return sun; }
    Inventory* getInventory() { return inventory; }
    bool getIsMousePressed() { return isMousePressed; }
    Clock& getLevelTimer() { return levelTimer; }
    PlantFactory** getPlantFactory() { return plantFactory; }
    ZombieFactory** getZombieFactory() { return zombieFactory; }
    string* getUnlockedPlants() { return unlockedPlants; }
    string* getUnlockedZombies() { return unlockedZombies; }
    int getCurrentPlantNum() { return currentPlantNum; }
    int getTotalNumberofPlants() { return totalNumberofPlants; }
    int getNumberofZombies() { return NumberofZombies; }


    void setBackgroundTexture(Texture& texture) { backgroundTexture = texture; }
    void setBackground(Sprite& sprite) { background = sprite; }
    void setGrid(Grid** gridPtr) { grid = gridPtr; }
    void setInventory(Inventory* inv) { inventory = inv; }
    void setIsMousePressed(bool pressed) { isMousePressed = pressed; }
    void setLevelTimer(Clock& clock) { levelTimer = clock; }
    void setPlantFactory(PlantFactory** factoryPtr) { plantFactory = factoryPtr; }
    void setZombieFactory(ZombieFactory** factoryPtr) { zombieFactory = factoryPtr; }
    void setCurrentPlantNum(int num) { currentPlantNum = num; }
    void setTotalNumberofPlants(int total) { totalNumberofPlants = total; }
    void setNumberofZombies(int numZombies) { NumberofZombies = numZombies; }
    


    void setupGrid() {
        float startX = 300.0f;
        float startY = 200.0f;
        float cellWidth = 90.0f;
        float cellHeight = 106.0f;

        grid = new Grid * [5];


        for (int i = 0; i < 5; ++i) {
            grid[i] = new Grid[9];
            for (int j = 0; j < 9; ++j) {
                grid[i][j] = Grid(startX + j * cellWidth, startY + i * cellHeight, cellWidth, cellHeight);
            }
        }
    }

    void drawGrid(sf::RenderWindow& window) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                grid[i][j].draw(window);
            }
        }
    }

    void setupBG() {
        background.setTexture(backgroundTexture);
        background.setPosition(0, 100);
    }
    Levels() :sun(window, false), window(window), totalNumberofPlants(45) {
        NumberofZombies = 0;
        currentPlantNum = 0;
        grid = NULL;
        inventory = NULL;
        cout << "level created";
        isMousePressed = 0;
        plantFactory = NULL;
        zombieFactory = NULL;
        unlockedPlants = 0;
        unlockedZombies = 0;
        srand(static_cast<unsigned int>(time(nullptr)));
    }
    void initZombiesMovement()
    {
        static int waveCounter = 0; // Static variable to keep track of waves
        static int zombiesToMove = 1; // Initial number of zombies to move

        if (levelTimer.getElapsedTime().asSeconds() > waveTime)
        {
            for (int i = 0; i < zombiesToMove; i++)
            {
                if (waveCounter < NumberofZombies)
                {
                    zombieFactory[waveCounter]->getZombie()->startMoving();
                    waveCounter++;
                }
                else
                {
                    break; // No more zombies to move
                }
            }

            zombiesToMove *= 2; // Double the number of zombies to move in the next wave
            waveTime *= 2; // Double the wave time for the next wave
        }
    }



};

class Level1 : public Levels 
{
    
public:
    Level1(RenderWindow& window): Levels()
    {
        cout << "creating level 1";
        backgroundTexture.loadFromFile("Images/bgdayrs.jpg");
        currentPlantNum = 0;
        totalNumberofPlants = 45;
        string* plants = new string[2];
        plants[0] = "peaShooter";
        plants[1] = "sunFlower";
        unlockedPlants = plants;
        cout << "allocating inventory\n";

        string* zombies = new string[1];
        zombies[0] = "simpleZombie";

        unlockedZombies = zombies;

        NumberofZombies = 3;
        
        inventory = new Inventory(unlockedPlants, 2);
        cout << "inventory allocated\n";
        setupBG();
        setupGrid();
    
        cout << "allocating factories\n";

        plantFactory = new PlantFactory * [totalNumberofPlants];
        zombieFactory = new ZombieFactory * [NumberofZombies];
        cout << "factories allocated\n";


        for (int i = 0; i < totalNumberofPlants; i++) {
            plantFactory[i] = nullptr; // Initialize all elements to nullptr
        }
        for (int i = 0; i < NumberofZombies; i++) {
            zombieFactory[i] = nullptr; // Initialize all elements to nullptr
        }
        isMousePressed = false;

        cout << "created level 1";
        spawnZombies();
    }
        

    virtual void spawnZombies() override{
        for (int i = 0; i < NumberofZombies; i++) {
            // Assuming random positions for demonstration
            int xPos = rand() % 200 + 1200; // Random X position between 100 and 900
            int yPos = rand() % 5;   // Random Y position between 100 and 600

            int y = grid[0][0].getY() + grid[0][0].getHeight() * yPos;
            zombieFactory[i] = new SimpleZombieFactory; // Example factory, adjust as needed
            zombieFactory[i]->createZombie(window, xPos, y);

        }
    }
        
        virtual int Duration() override
        {
            return 120;
        }

        virtual int getLevelNumber() override
        {
            return 1;
        }
        virtual int getWaveCount() override
        {
            return 1;
        }


        virtual void draw(RenderWindow & window) override {
            setupBG();
            window.draw(background);
            inventory->draw(window);

            drawGrid(window);
            sun.draw(window);
            for (int i = 0; i < currentPlantNum; i++)
            {
                if (plantFactory[i])
                    plantFactory[i]->getPlant()->draw(window);

            }
            
            for (int i = 0; i < NumberofZombies; i++)
            {
                if (zombieFactory[i] != nullptr)
                    zombieFactory[i]->getZombie()->draw(window);
            }
            
        }


        virtual void identifyCard(int i) override {
            if (inventory->getPlantCard(i).plantId == "peaShooter")
            {

                plantFactory[currentPlantNum] = new PeaShooterFactory;
            }
            else if (inventory->getPlantCard(i).plantId == "sunFlower")
            {

                plantFactory[currentPlantNum] = new SunFlowerFactory;
            }
        }


       
    
    ~Level1() 
    {
        cout << "deleting level 1;";
        for (int i = 0; i < 5; i++) {
            if(grid[i])
                delete[] grid[i];
        }
        if (grid)
            delete[] grid;
        for (int i = 0; i < totalNumberofPlants; i++) {
            if(plantFactory[i])
                delete plantFactory[i];
        }
        if(plantFactory)
        delete[] plantFactory;

        // Delete zombieFactory objects
        for (int i = 0; i < NumberofZombies; i++) {
            if(zombieFactory[i])
                delete zombieFactory[i];
        }
        if(zombieFactory)
            delete[] zombieFactory;
        if(inventory)
            delete inventory;

        // Delete grid objects
        
        cout << "deleted level 1;";
    }
        
    
};

class Level2 : public Levels 
{
public:
    Level2(RenderWindow& window) : Levels()
    {

        backgroundTexture.loadFromFile("Images/limitedbgrs.jpg");
        currentPlantNum = 0;
        totalNumberofPlants = 45;
        string* plants = new string[4];
        plants[0] = "peaShooter";
        plants[1] = "sunFlower";
        plants[2] = "wallNut";
        plants[3] = "cherryBomb";

        unlockedPlants = plants;
        inventory = new Inventory(unlockedPlants, 4);
        NumberofZombies = 17;

        string* zombies = new string[4];
        zombies[0] = "simpleZombie";
        zombies[1] = "footballZombie";
        zombies[2] = "flyingZombie";
        zombies[3] = "dancingZombie";

        unlockedZombies = zombies;


        setupBG();
        setupGrid();
        plantFactory = new PlantFactory * [totalNumberofPlants];
        zombieFactory = new ZombieFactory * [NumberofZombies];

        for (int i = 0; i < totalNumberofPlants; i++) {
            plantFactory[i] = nullptr; // Initialize all elements to nullptr
        }
        for (int i = 0; i < NumberofZombies; i++) {
            zombieFactory[i] = nullptr; // Initialize all elements to nullptr
        }
        isMousePressed = false;

        cout << "created level 2";
        spawnZombies();
        
    }

    ~Level2() {

        for (int i = 0; i < 5; i++) {
            if (grid[i])
                delete[] grid[i];
        }
        if (grid)
            delete[] grid;
        for (int i = 0; i < totalNumberofPlants; i++) {
            if (plantFactory[i])
                delete plantFactory[i];
        }
        if (plantFactory)
            delete[] plantFactory;

        // Delete zombieFactory objects
        for (int i = 0; i < NumberofZombies; i++) {
            if (zombieFactory[i])
                delete zombieFactory[i];
        }
        if (zombieFactory)
            delete[] zombieFactory;
        if (inventory)
            delete inventory;

    }

    virtual void spawnZombies() override {
        for (int i = 0; i < NumberofZombies; i++) {
            // Assuming random positions for demonstration
            int xPos = rand() % 350 + 1200; // Random X position between 100 and 900
            int yPos = rand() % 5;   // Random Y position between 100 and 600

            int y = grid[0][0].getY() + grid[0][0].getHeight() * yPos;
            if(i < 10)
            {
                zombieFactory[i] = new SimpleZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
            else if (i <= 13 && i >=10)
            {
                zombieFactory[i] = new FootballZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
            else if (i == 14)
            {
                zombieFactory[i] = new FlyingZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
            else
            {
                zombieFactory[i] = new DancingZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
        }
    }


    virtual int Duration() override
    {
        return 180;
    }


    virtual int getLevelNumber() override
    {
        return 1;
    }
    virtual int getWaveCount() override
    {
        return 1;
    }

    virtual void draw(RenderWindow& window) override {
        setupBG();
        window.draw(background);
        inventory->draw(window);

        drawGrid(window);
        sun.draw(window);
        for (int i = 0; i < currentPlantNum; i++)
        {
            if (plantFactory[i])
                plantFactory[i]->getPlant()->draw(window);

        }

        for (int i = 0; i < NumberofZombies; i++)
        {
            if (zombieFactory[i] != nullptr)
                zombieFactory[i]->getZombie()->draw(window);
        }

    }


    virtual void identifyCard(int i) override {
        if (inventory->getPlantCard(i).plantId == "peaShooter")
        {
            
            plantFactory[currentPlantNum] = new PeaShooterFactory;
        }
        else if (inventory->getPlantCard(i).plantId == "sunFlower")
        {

            plantFactory[currentPlantNum] = new SunFlowerFactory;
        }
        else if (inventory->getPlantCard(i).plantId == "wallNut")
        {

            plantFactory[currentPlantNum] = new wallNutFactory;
        }
        else if (inventory->getPlantCard(i).plantId == "cherryBomb")
        {

            plantFactory[currentPlantNum] = new CherryBombFactory;
        }
    }
    
    

};


class Level3 : public Levels
{
public:
    Level3(RenderWindow& window) : Levels()
    {

        backgroundTexture.loadFromFile("Images/limitedbgrs.jpg");
        currentPlantNum = 0;
        totalNumberofPlants = 45;
        string* plants = new string[6];
        plants[0] = "peaShooter";
        plants[1] = "sunFlower";
        plants[2] = "wallNut";
        plants[3] = "cherryBomb";
        plants[4] = "repeater";
        plants[5] = "snowPea";

        unlockedPlants = plants;
        inventory = new Inventory(unlockedPlants, 6);
        NumberofZombies = 25;

        string* zombies = new string[4];
        zombies[0] = "simpleZombie";
        zombies[1] = "footballZombie";
        zombies[2] = "flyingZombie";
        zombies[3] = "dancingZombie";

        unlockedZombies = zombies;


        setupBG();
        setupGrid();
        plantFactory = new PlantFactory * [totalNumberofPlants];
        zombieFactory = new ZombieFactory * [NumberofZombies];

        for (int i = 0; i < totalNumberofPlants; i++) {
            plantFactory[i] = nullptr; // Initialize all elements to nullptr
        }
        for (int i = 0; i < NumberofZombies; i++) {
            zombieFactory[i] = nullptr; // Initialize all elements to nullptr
        }
        isMousePressed = false;

        cout << "created level 2";
        spawnZombies();

    }

    ~Level3() {

        for (int i = 0; i < 5; i++) {
            if (grid[i])
                delete[] grid[i];
        }
        if (grid)
            delete[] grid;
        for (int i = 0; i < totalNumberofPlants; i++) {
            if (plantFactory[i])
                delete plantFactory[i];
        }
        if (plantFactory)
            delete[] plantFactory;

        // Delete zombieFactory objects
        for (int i = 0; i < NumberofZombies; i++) {
            if (zombieFactory[i])
                delete zombieFactory[i];
        }
        if (zombieFactory)
            delete[] zombieFactory;
        if (inventory)
            delete inventory;

    }

    virtual void spawnZombies() override {
        for (int i = 0; i < NumberofZombies; i++) {
            // Assuming random positions for demonstration
            int xPos = rand() % 350 + 1200; // Random X position between 100 and 900
            int yPos = rand() % 5;   // Random Y position between 100 and 600

            int y = grid[0][0].getY() + grid[0][0].getHeight() * yPos;
            if (i < 15)
            {
                zombieFactory[i] = new SimpleZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
            else if (i <= 19 && i >= 15)
            {
                zombieFactory[i] = new FootballZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
            else if (i == 20)
            {
                zombieFactory[i] = new FlyingZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
            else
            {
                zombieFactory[i] = new DancingZombieFactory; // Example factory, adjust as needed
                zombieFactory[i]->createZombie(window, xPos, y);
            }
        }
    }


    virtual int Duration() override
    {
        return 180;
    }


    virtual int getLevelNumber() override
    {
        return 1;
    }
    virtual int getWaveCount() override
    {
        return 1;
    }

    virtual void draw(RenderWindow& window) override {
        setupBG();
        window.draw(background);
        inventory->draw(window);

        drawGrid(window);
        sun.draw(window);
        for (int i = 0; i < currentPlantNum; i++)
        {
            if (plantFactory[i])
                plantFactory[i]->getPlant()->draw(window);

        }

        for (int i = 0; i < NumberofZombies; i++)
        {
            if (zombieFactory[i] != nullptr)
                zombieFactory[i]->getZombie()->draw(window);
        }

    }


    virtual void identifyCard(int i) override {
        if (inventory->getPlantCard(i).plantId == "peaShooter")
        {

            plantFactory[currentPlantNum] = new PeaShooterFactory;
        }
        else if (inventory->getPlantCard(i).plantId == "sunFlower")
        {

            plantFactory[currentPlantNum] = new SunFlowerFactory;
        }
        else if (inventory->getPlantCard(i).plantId == "wallNut")
        {

            plantFactory[currentPlantNum] = new wallNutFactory;
        }
        else if (inventory->getPlantCard(i).plantId == "cherryBomb")
        {

            plantFactory[currentPlantNum] = new CherryBombFactory;
        }
        else if (inventory->getPlantCard(i).plantId == "repeater")
        {

            plantFactory[currentPlantNum] = new RepeaterFactory;
        }

        else if (inventory->getPlantCard(i).plantId == "snowPea")
        {

            plantFactory[currentPlantNum] = new SnowPeaFactory;
        }
    }



};


#endif //LEVELS_H