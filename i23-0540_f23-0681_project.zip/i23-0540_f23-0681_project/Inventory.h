#ifndef INVENTORY_H
#define INVENTORY_H
#include <SFML/Graphics.hpp>


using namespace sf;
using namespace std;

class PlantCard {
public:
	string plantId;
	Sprite plantSprite;
	Texture plantTexture;
	bool isUnlocked;
	bool isBeingDragged;
	float originalX, originalY;
	Clock respawntime;
	int price;
	PlantCard() : isUnlocked(false), isBeingDragged(false), originalX(0), originalY(0) {}
	void setOriginalX(float x) { originalX = x; }
	void setOriginalY(float y) { originalY = y; }
	float getOriginalX() { return originalX; }
	float getOriginalY() { return originalY; }

	void startDrag()
	{
		isBeingDragged = true;
	}
	void updateDrag(float mouseX, float mouseY)
	{
		plantSprite.setPosition(mouseX-25, mouseY-25);
	}
	void endDrag() {
		isBeingDragged = false;
	}
	void setPrice(int n) { price = n; }
	int getPrice() { return price; }
};

class Inventory {
	PlantCard* plantCards;
	int numSlots;
	Sprite InventorySprite;
	Texture InventoryTexture;
	bool dragging;


public:
	Inventory(string* unlockedPlants, int NumberofPlants) {
		
		numSlots = NumberofPlants;
		plantCards = new PlantCard[numSlots];

		for (int i = 0; i < numSlots; i++)
			cout << unlockedPlants[i] << endl;
		for (int i = 0; i < numSlots; i++)
		{
				plantCards[i].plantId = unlockedPlants[i];
				plantCards[i].plantTexture.loadFromFile("Images/card" + plantCards[i].plantId + ".png");
				plantCards[i].plantSprite.setTexture(plantCards[i].plantTexture);
				plantCards[i].plantSprite.setPosition(90+i*67, 83);
				plantCards[i].setOriginalX(90 + i * 67);
				plantCards[i].setOriginalY(83);
				plantCards[i].price = 100;
				plantCards[i].isUnlocked = true; // Mark the card as unlocked
				if(plantCards[i].plantId == "wallNut")
					plantCards[i].price = 50;
				if (plantCards[i].plantId == "cherryBomb")
					plantCards[i].price = 150;
				if (plantCards[i].plantId == "repeater")
					plantCards[i].price = 200;


		}
		InventoryTexture.loadFromFile("Images/ChooserBackground.png");
		InventorySprite.setTexture(InventoryTexture);
		InventorySprite.setPosition(10, 80);
		
	
	}

	~Inventory() {
		delete[] plantCards;
	}

	void updateDraggedCardPosition(float mouseX, float mouseY) {
		for (int i = 0; i < numSlots; i++) {
			if (plantCards[i].isBeingDragged) {
				plantCards[i].updateDrag(mouseX, mouseY);
			}
		}
	}
	PlantCard* getDraggedCard(float mouseX, float mouseY) {
		for (int i = 0; i < numSlots; i++) {
			if (plantCards[i].isUnlocked && plantCards[i].plantSprite.getGlobalBounds().contains(mouseX, mouseY) && !dragging) {
				plantCards[i].startDrag();
				
				return &plantCards[i];

			}
		}
		return nullptr;
	}

	int getNumSlots() { return numSlots; }
	PlantCard& getPlantCard(int index) {
		if (index >= 0 && index < numSlots) {
			return plantCards[index];
		}
		else {
			throw std::out_of_range("Invalid index for accessing plant card.");
		}
	}
	void draw(RenderWindow& window) {
		window.draw(InventorySprite);
		for (int i = 0; i < numSlots; i++) {
			if (plantCards[i].isUnlocked) {
				window.draw(plantCards[i].plantSprite);
			}
		}
	}

	
};




#endif // !INVENTORY_H
